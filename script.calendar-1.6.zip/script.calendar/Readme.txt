This work is licensed under the Creative Commons Paternité - 
Pas d'Utilisation Commerciale - 
Partage à l'Identique 3.0 non transcrit License. 
To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to 
Creative Commons, 444 Castro Street, Suite 900, Mountain View, California, 94041, USA.
